# $Id: TransferResult.pm,v 1.2 2000/10/12 19:03:44 davidb Exp $

# Copyright (c) 1997-2000 Network Solutions, Inc.
# See the file LICENSE for conditions of use and distribution.

package Net::Rwhois::TransferResult;

require 5.003;

use Carp;
use Net::Rwhois::Connection;
use Net::Rwhois::RwhoisObject;

use strict;
use vars qw(@ISA $VERSION);

# use Exporter;
# @ISA       = qw( Exporter );
# @EXPORT_OK = qw();

##
## Public Methods
##

1;
